﻿/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.lang['cs'] = {
    undo : 
    {
    	redo : 'Znovu',
    	undo : 'Zpět'
    },
    toolbar : 
    {
    	toolbarCollapse : 'Skrýt panel nástrojů',
    	toolbarExpand : 'Zobrazit panel nástrojů',
    	toolbarGroups : 
    	{
    		document : 'Dokument',
    		clipboard : 'Schránka/Zpět',
    		editing : 'Úpravy',
    		forms : 'Formuláře',
    		basicstyles : 'Základní styly',
    		paragraph : 'Odstavec',
    		links : 'Odkazy',
    		insert : 'Vložit',
    		styles : 'Styly',
    		colors : 'Barvy',
    		tools : 'Nástroje'
    	},
    	toolbars : 'Panely nástrojů editoru'
    },
    templates : 
    {
    	button : 'Šablony',
    	emptyListMsg : '(Není definována žádná šablona)',
    	insertOption : 'Nahradit aktuální obsah',
    	options : 'Nastavení šablon',
    	selectPromptMsg : 'Prosím zvolte šablonu pro otevření v editoru<br>(aktuální obsah editoru bude ztracen):',
    	title : 'Šablony obsahu'
    },
    table : 
    {
    	border : 'Ohraničení',
    	caption : 'Popis',
    	cell : 
    	{
    		menu : 'Buňka',
    		insertBefore : 'Vložit buňku před',
    		insertAfter : 'Vložit buňku za',
    		deleteCell : 'Smazat buňky',
    		merge : 'Sloučit buňky',
    		mergeRight : 'Sloučit doprava',
    		mergeDown : 'Sloučit dolů',
    		splitHorizontal : 'Rozdělit buňky vodorovně',
    		splitVertical : 'Rozdělit buňky svisle',
    		title : 'Vlastnosti buňky',
    		cellType : 'Typ buňky',
    		rowSpan : 'Spojit řádky',
    		colSpan : 'Spojit sloupce',
    		wordWrap : 'Zalamování',
    		hAlign : 'Vodorovné zarovnání',
    		vAlign : 'Svislé zarovnání',
    		alignBaseline : 'Na účaří',
    		bgColor : 'Barva pozadí',
    		borderColor : 'Barva okraje',
    		data : 'Data',
    		header : 'Hlavička',
    		yes : 'Ano',
    		no : 'Ne',
    		invalidWidth : 'Šířka buňky musí být číslo.',
    		invalidHeight : 'Zadaná výška buňky musí být číslená.',
    		invalidRowSpan : 'Zadaný počet sloučených řádků musí být celé číslo.',
    		invalidColSpan : 'Zadaný počet sloučených sloupců musí být celé číslo.',
    		chooseColor : 'Výběr'
    	},
    	cellPad : 'Odsazení obsahu v buňce',
    	cellSpace : 'Vzdálenost buněk',
    	column : 
    	{
    		menu : 'Sloupec',
    		insertBefore : 'Vložit sloupec před',
    		insertAfter : 'Vložit sloupec za',
    		deleteColumn : 'Smazat sloupec'
    	},
    	columns : 'Sloupce',
    	deleteTable : 'Smazat tabulku',
    	headers : 'Záhlaví',
    	headersBoth : 'Obojí',
    	headersColumn : 'První sloupec',
    	headersNone : 'Žádné',
    	headersRow : 'První řádek',
    	invalidBorder : 'Zdaná velikost okraje musí být číselná.',
    	invalidCellPadding : 'Zadané odsazení obsahu v buňce musí být číselné.',
    	invalidCellSpacing : 'Zadaná vzdálenost buněk musí být číselná.',
    	invalidCols : 'Počet sloupců musí být číslo větší než 0.',
    	invalidHeight : 'Zadaná výška tabulky musí být číselná.',
    	invalidRows : 'Počet řádků musí být číslo větší než 0.',
    	invalidWidth : 'Šířka tabulky musí být číslo.',
    	menu : 'Vlastnosti tabulky',
    	row : 
    	{
    		menu : 'Řádek',
    		insertBefore : 'Vložit řádek před',
    		insertAfter : 'Vložit řádek za',
    		deleteRow : 'Smazat řádky'
    	},
    	rows : 'Řádky',
    	summary : 'Souhrn',
    	title : 'Vlastnosti tabulky',
    	toolbar : 'Tabulka',
    	widthPc : 'procent',
    	widthPx : 'bodů',
    	widthUnit : 'jednotka šířky'
    },
    stylescombo : 
    {
    	label : 'Styl',
    	panelTitle : 'Formátovací styly',
    	panelTitle1 : 'Blokové styly',
    	panelTitle2 : 'Řádkové styly',
    	panelTitle3 : 'Objektové styly'
    },
    specialchar : 
    {
    	options : 'Nastavení speciálních znaků',
    	title : 'Výběr speciálního znaku',
    	toolbar : 'Vložit speciální znaky'
    },
    sourcearea : 
    {
    	toolbar : 'Zdroj'
    },
    smiley : 
    {
    	options : 'Nastavení smajlíků',
    	title : 'Vkládání smajlíků',
    	toolbar : 'Smajlíci'
    },
    showblocks : 
    {
    	toolbar : 'Ukázat bloky'
    },
    selectall : 
    {
    	toolbar : 'Vybrat vše'
    },
    save : 
    {
    	toolbar : 'Uložit'
    },
    removeformat : 
    {
    	toolbar : 'Odstranit formátování'
    },
    print : 
    {
    	toolbar : 'Tisk'
    },
    preview : 
    {
    	preview : 'Náhled'
    },
    pastetext : 
    {
    	button : 'Vložit jako čistý text',
    	title : 'Vložit jako čistý text'
    },
    pastefromword : 
    {
    	confirmCleanup : 'Jak je vidět, vkládaný text je kopírován z Wordu. Chcete jej před vložením vyčistit?',
    	error : 'Z důvodu vnitřní chyby nebylo možné provést vyčištění vkládaného textu.',
    	title : 'Vložit z Wordu',
    	toolbar : 'Vložit z Wordu'
    },
    pagebreak : 
    {
    	alt : 'Konec stránky',
    	toolbar : 'Vložit konec stránky'
    },
    newpage : 
    {
    	toolbar : 'Nová stránka'
    },
    maximize : 
    {
    	maximize : 'Maximalizovat',
    	minimize : 'Minimalizovat'
    },
    magicline : 
    {
    	title : 'zde vložit odstavec'
    },
    liststyle : 
    {
    	armenian : 'Arménské',
    	bulletedTitle : 'Vlastnosti odrážek',
    	circle : 'Kroužky',
    	decimal : 'Arabská čísla (1, 2, 3, atd.)',
    	decimalLeadingZero : 'Arabská čísla uvozená nulou (01, 02, 03, atd.)',
    	disc : 'Kolečka',
    	georgian : 'Gruzínské (an, ban, gan, atd.)',
    	lowerAlpha : 'Malá latinka (a, b, c, d, e, atd.)',
    	lowerGreek : 'Malé řecké (alpha, beta, gamma, atd.)',
    	lowerRoman : 'Malé římské (i, ii, iii, iv, v, atd.)',
    	none : 'Nic',
    	notset : '<nenastaveno>',
    	numberedTitle : 'Vlastnosti číslování',
    	square : 'Čtverce',
    	start : 'Počátek',
    	type : 'Typ',
    	upperAlpha : 'Velká latinka (A, B, C, D, E, atd.)',
    	upperRoman : 'Velké římské (I, II, III, IV, V, atd.)',
    	validateStartNumber : 'Číslování musí začínat celým číslem.'
    },
    list : 
    {
    	bulletedlist : 'Odrážky',
    	numberedlist : 'Číslování'
    },
    link : 
    {
    	acccessKey : 'Přístupový klíč',
    	advanced : 'Rozšířené',
    	advisoryContentType : 'Pomocný typ obsahu',
    	advisoryTitle : 'Pomocný titulek',
    	anchor : 
    	{
    		toolbar : 'Záložka',
    		menu : 'Vlastnosti záložky',
    		title : 'Vlastnosti záložky',
    		name : 'Název záložky',
    		errorName : 'Zadejte prosím název záložky',
    		remove : 'Odstranit záložku'
    	},
    	anchorId : 'Podle Id objektu',
    	anchorName : 'Podle jména kotvy',
    	charset : 'Přiřazená znaková sada',
    	cssClasses : 'Třída stylu',
    	download : 'Force Download',
    	displayText : 'Zobrazit text',
    	emailAddress : 'E-mailová adresa',
    	emailBody : 'Tělo zprávy',
    	emailSubject : 'Předmět zprávy',
    	id : 'Id',
    	info : 'Informace o odkazu',
    	langCode : 'Kód jazyka',
    	langDir : 'Směr jazyka',
    	langDirLTR : 'Zleva doprava (LTR)',
    	langDirRTL : 'Zprava doleva (RTL)',
    	menu : 'Změnit odkaz',
    	name : 'Jméno',
    	noAnchors : '(Ve stránce není definována žádná kotva!)',
    	noEmail : 'Zadejte prosím e-mailovou adresu',
    	noUrl : 'Zadejte prosím URL odkazu',
    	other : '<jiný>',
    	popupDependent : 'Závislost (Netscape)',
    	popupFeatures : 'Vlastnosti vyskakovacího okna',
    	popupFullScreen : 'Celá obrazovka (IE)',
    	popupLeft : 'Levý okraj',
    	popupLocationBar : 'Panel umístění',
    	popupMenuBar : 'Panel nabídky',
    	popupResizable : 'Umožňující měnit velikost',
    	popupScrollBars : 'Posuvníky',
    	popupStatusBar : 'Stavový řádek',
    	popupToolbar : 'Panel nástrojů',
    	popupTop : 'Horní okraj',
    	rel : 'Vztah',
    	selectAnchor : 'Vybrat kotvu',
    	styles : 'Styl',
    	tabIndex : 'Pořadí prvku',
    	target : 'Cíl',
    	targetFrame : '<rámec>',
    	targetFrameName : 'Název cílového rámu',
    	targetPopup : '<vyskakovací okno>',
    	targetPopupName : 'Název vyskakovacího okna',
    	title : 'Odkaz',
    	toAnchor : 'Kotva v této stránce',
    	toEmail : 'E-mail',
    	toUrl : 'URL',
    	toolbar : 'Odkaz',
    	type : 'Typ odkazu',
    	unlink : 'Odstranit odkaz',
    	upload : 'Odeslat'
    },
    justify : 
    {
    	block : 'Zarovnat do bloku',
    	center : 'Zarovnat na střed',
    	left : 'Zarovnat vlevo',
    	right : 'Zarovnat vpravo'
    },
    indent : 
    {
    	indent : 'Zvětšit odsazení',
    	outdent : 'Zmenšit odsazení'
    },
    image : 
    {
    	alt : 'Alternativní text',
    	border : 'Okraje',
    	btnUpload : 'Odeslat na server',
    	button2Img : 'Skutečně chcete převést zvolené obrázkové tlačítko na obyčejný obrázek?',
    	hSpace : 'Horizontální mezera',
    	img2Button : 'Skutečně chcete převést zvolený obrázek na obrázkové tlačítko?',
    	infoTab : 'Informace o obrázku',
    	linkTab : 'Odkaz',
    	lockRatio : 'Zámek',
    	menu : 'Vlastnosti obrázku',
    	resetSize : 'Původní velikost',
    	title : 'Vlastnosti obrázku',
    	titleButton : 'Vlastností obrázkového tlačítka',
    	upload : 'Odeslat',
    	urlMissing : 'Zadané URL zdroje obrázku nebylo nalezeno.',
    	vSpace : 'Vertikální mezera',
    	validateBorder : 'Okraj musí být nastaven v celých číslech.',
    	validateHSpace : 'Horizontální mezera musí být nastavena v celých číslech.',
    	validateVSpace : 'Vertikální mezera musí být nastavena v celých číslech.'
    },
    iframe : 
    {
    	border : 'Zobrazit okraj',
    	noUrl : 'Zadejte prosím URL obsahu pro IFrame',
    	scrolling : 'Zapnout posuvníky',
    	title : 'Vlastnosti IFrame',
    	toolbar : 'IFrame'
    },
    horizontalrule : 
    {
    	toolbar : 'Vložit vodorovnou linku'
    },
    forms : 
    {
    	button : 
    	{
    		title : 'Vlastnosti tlačítka',
    		text : 'Popisek',
    		type : 'Typ',
    		typeBtn : 'Tlačítko',
    		typeSbm : 'Odeslat',
    		typeRst : 'Obnovit'
    	},
    	checkboxAndRadio : 
    	{
    		checkboxTitle : 'Vlastnosti zaškrtávacího políčka',
    		radioTitle : 'Vlastnosti přepínače',
    		value : 'Hodnota',
    		selected : 'Zaškrtnuto',
    		required : 'Vyžadováno'
    	},
    	form : 
    	{
    		title : 'Vlastnosti formuláře',
    		menu : 'Vlastnosti formuláře',
    		action : 'Akce',
    		method : 'Metoda',
    		encoding : 'Kódování'
    	},
    	hidden : 
    	{
    		title : 'Vlastnosti skrytého pole',
    		name : 'Název',
    		value : 'Hodnota'
    	},
    	select : 
    	{
    		title : 'Vlastnosti seznamu',
    		selectInfo : 'Info',
    		opAvail : 'Dostupná nastavení',
    		value : 'Hodnota',
    		size : 'Velikost',
    		lines : 'Řádků',
    		chkMulti : 'Povolit mnohonásobné výběry',
    		required : 'Vyžadováno',
    		opText : 'Text',
    		opValue : 'Hodnota',
    		btnAdd : 'Přidat',
    		btnModify : 'Změnit',
    		btnUp : 'Nahoru',
    		btnDown : 'Dolů',
    		btnSetValue : 'Nastavit jako vybranou hodnotu',
    		btnDelete : 'Smazat'
    	},
    	textarea : 
    	{
    		title : 'Vlastnosti textové oblasti',
    		cols : 'Sloupců',
    		rows : 'Řádků'
    	},
    	textfield : 
    	{
    		title : 'Vlastnosti textového pole',
    		name : 'Název',
    		value : 'Hodnota',
    		charWidth : 'Šířka ve znacích',
    		maxChars : 'Maximální počet znaků',
    		required : 'Vyžadováno',
    		type : 'Typ',
    		typeText : 'Text',
    		typePass : 'Heslo',
    		typeEmail : 'Email',
    		typeSearch : 'Hledat',
    		typeTel : 'Telefonní číslo',
    		typeUrl : 'URL'
    	}
    },
    format : 
    {
    	label : 'Formát',
    	panelTitle : 'Formát',
    	tag_address : 'Adresa',
    	tag_div : 'Normální (DIV)',
    	tag_h1 : 'Nadpis 1',
    	tag_h2 : 'Nadpis 2',
    	tag_h3 : 'Nadpis 3',
    	tag_h4 : 'Nadpis 4',
    	tag_h5 : 'Nadpis 5',
    	tag_h6 : 'Nadpis 6',
    	tag_p : 'Normální',
    	tag_pre : 'Naformátováno'
    },
    font : 
    {
    	fontSize : 
    	{
    		label : 'Velikost',
    		voiceLabel : 'Velikost písma',
    		panelTitle : 'Velikost'
    	},
    	label : 'Písmo',
    	panelTitle : 'Písmo',
    	voiceLabel : 'Písmo'
    },
    flash : 
    {
    	access : 'Přístup ke skriptu',
    	accessAlways : 'Vždy',
    	accessNever : 'Nikdy',
    	accessSameDomain : 'Ve stejné doméně',
    	alignAbsBottom : 'Zcela dolů',
    	alignAbsMiddle : 'Doprostřed',
    	alignBaseline : 'Na účaří',
    	alignTextTop : 'Na horní okraj textu',
    	bgcolor : 'Barva pozadí',
    	chkFull : 'Povolit celoobrazovkový režim',
    	chkLoop : 'Opakování',
    	chkMenu : 'Nabídka Flash',
    	chkPlay : 'Automatické spuštění',
    	flashvars : 'Proměnné pro Flash',
    	hSpace : 'Horizontální mezera',
    	properties : 'Vlastnosti Flashe',
    	propertiesTab : 'Vlastnosti',
    	quality : 'Kvalita',
    	qualityAutoHigh : 'Vysoká - auto',
    	qualityAutoLow : 'Nízká - auto',
    	qualityBest : 'Nejlepší',
    	qualityHigh : 'Vysoká',
    	qualityLow : 'Nejnižší',
    	qualityMedium : 'Střední',
    	scale : 'Zobrazit',
    	scaleAll : 'Zobrazit vše',
    	scaleFit : 'Přizpůsobit',
    	scaleNoBorder : 'Bez okraje',
    	title : 'Vlastnosti Flashe',
    	vSpace : 'Vertikální mezera',
    	validateHSpace : 'Zadaná horizontální mezera musí být číslo.',
    	validateSrc : 'Zadejte prosím URL odkazu',
    	validateVSpace : 'Zadaná vertikální mezera musí být číslo.',
    	windowMode : 'Režim okna',
    	windowModeOpaque : 'Neprůhledné',
    	windowModeTransparent : 'Průhledné',
    	windowModeWindow : 'Okno'
    },
    find : 
    {
    	find : 'Hledat',
    	findOptions : 'Možnosti hledání',
    	findWhat : 'Co hledat:',
    	matchCase : 'Rozlišovat velikost písma',
    	matchCyclic : 'Procházet opakovaně',
    	matchWord : 'Pouze celá slova',
    	notFoundMsg : 'Hledaný text nebyl nalezen.',
    	replace : 'Nahradit',
    	replaceAll : 'Nahradit vše',
    	replaceSuccessMsg : '%1 nahrazení.',
    	replaceWith : 'Čím nahradit:',
    	title : 'Najít a nahradit'
    },
    fakeobjects : 
    {
    	anchor : 'Záložka',
    	flash : 'Flash animace',
    	hiddenfield : 'Skryté pole',
    	iframe : 'IFrame',
    	unknown : 'Neznámý objekt'
    },
    elementspath : 
    {
    	eleLabel : 'Cesta objektu',
    	eleTitle : '%1 objekt'
    },
    div : 
    {
    	IdInputLabel : 'Id',
    	advisoryTitleInputLabel : 'Nápovědní titulek',
    	cssClassInputLabel : 'Třídy stylů',
    	edit : 'Změnit Div',
    	inlineStyleInputLabel : 'Vnitřní styly',
    	langDirLTRLabel : 'Zleva doprava (LTR)',
    	langDirLabel : 'Směr jazyka',
    	langDirRTLLabel : 'Zprava doleva (RTL)',
    	languageCodeInputLabel : ' Kód jazyka',
    	remove : 'Odstranit Div',
    	styleSelectLabel : 'Styly',
    	title : 'Vytvořit Div kontejner',
    	toolbar : 'Vytvořit Div kontejner'
    },
    contextmenu : 
    {
    	options : 'Nastavení kontextové nabídky'
    },
    colordialog : 
    {
    	clear : 'Vyčistit',
    	highlight : 'Zvýraznit',
    	options : 'Nastavení barvy',
    	selected : 'Vybráno',
    	title : 'Výběr barvy'
    },
    colorbutton : 
    {
    	auto : 'Automaticky',
    	bgColorTitle : 'Barva pozadí',
    	colors : 
    	{
    		'000' : 'Černá',
    		'800000' : 'Kaštanová',
    		'8B4513' : 'Sedlová hněď',
    		'2F4F4F' : 'Tmavě bledě šedá',
    		'008080' : 'Čírka',
    		'000080' : 'Námořnická modř',
    		'4B0082' : 'Inkoustová',
    		'696969' : 'Tmavě šedá',
    		B22222 : 'Pálená cihla',
    		A52A2A : 'Hnědá',
    		DAA520 : 'Zlatý prut',
    		'006400' : 'Tmavě zelená',
    		'40E0D0' : 'Tyrkisová',
    		'0000CD' : 'Středně modrá',
    		'800080' : 'Purpurová',
    		'808080' : 'Šedá',
    		F00 : 'Červená',
    		FF8C00 : 'Tmavě oranžová',
    		FFD700 : 'Zlatá',
    		'008000' : 'Zelená',
    		'0FF' : 'Azurová',
    		'00F' : 'Modrá',
    		EE82EE : 'Fialová',
    		A9A9A9 : 'Kalně šedá',
    		FFA07A : 'Světle lososová',
    		FFA500 : 'Oranžová',
    		FFFF00 : 'Žlutá',
    		'00FF00' : 'Limetková',
    		AFEEEE : 'Bledě tyrkisová',
    		ADD8E6 : 'Světle modrá',
    		DDA0DD : 'Švestková',
    		D3D3D3 : 'Světle šedá',
    		FFF0F5 : 'Levandulově ruměnná',
    		FAEBD7 : 'Antická bílá',
    		FFFFE0 : 'Světle žlutá',
    		F0FFF0 : 'Medová rosa',
    		F0FFFF : 'Azurová',
    		F0F8FF : 'Alenčina modrá',
    		E6E6FA : 'Levandulová',
    		FFF : 'Bílá'
    	},
    	more : 'Více barev...',
    	panelTitle : 'Barvy',
    	textColorTitle : 'Barva textu'
    },
    clipboard : 
    {
    	copy : 'Kopírovat',
    	copyError : 'Bezpečnostní nastavení vašeho prohlížeče nedovolují editoru spustit funkci pro kopírování zvoleného textu do schránky. Prosím zkopírujte zvolený text do schránky pomocí klávesnice (Ctrl/Cmd+C).',
    	cut : 'Vyjmout',
    	cutError : 'Bezpečnostní nastavení vašeho prohlížeče nedovolují editoru spustit funkci pro vyjmutí zvoleného textu do schránky. Prosím vyjměte zvolený text do schránky pomocí klávesnice (Ctrl/Cmd+X).',
    	paste : 'Vložit',
    	pasteArea : 'Oblast vkládání',
    	pasteMsg : 'Do následujícího pole vložte požadovaný obsah pomocí klávesnice (<STRONG>Ctrl/Cmd+V</STRONG>) a stiskněte <STRONG>OK</STRONG>.',
    	securityMsg : 'Z důvodů nastavení bezpečnosti vašeho prohlížeče nemůže editor přistupovat přímo do schránky. Obsah schránky prosím vložte znovu do tohoto okna.',
    	title : 'Vložit'
    },
    button : 
    {
    	selectedLabel : '%1 (Vybráno)'
    },
    blockquote : 
    {
    	toolbar : 'Citace'
    },
    bidi : 
    {
    	ltr : 'Směr textu zleva doprava',
    	rtl : 'Směr textu zprava doleva'
    },
    basicstyles : 
    {
    	bold : 'Tučné',
    	italic : 'Kurzíva',
    	strike : 'Přeškrtnuté',
    	subscript : 'Dolní index',
    	superscript : 'Horní index',
    	underline : 'Podtržené'
    },
    about : 
    {
    	copy : 'Copyright &copy; $1. All rights reserved.',
    	dlgTitle : 'O aplikaci CKEditor',
    	help : 'Prohlédněte si $1 pro nápovědu.',
    	moreInfo : 'Pro informace o lincenci navštivte naši webovou stránku:',
    	title : 'O aplikaci CKEditor',
    	userGuide : 'Uživatelská příručka CKEditor'
    },
    editor : 'Textový editor',
    editorPanel : 'Panel textového editoru',
    common : 
    {
    	editorHelp : 'Stiskněte ALT 0 pro nápovědu',
    	browseServer : 'Vybrat na serveru',
    	url : 'URL',
    	protocol : 'Protokol',
    	upload : 'Odeslat',
    	uploadSubmit : 'Odeslat na server',
    	image : 'Obrázek',
    	flash : 'Flash',
    	form : 'Formulář',
    	checkbox : 'Zaškrtávací políčko',
    	radio : 'Přepínač',
    	textField : 'Textové pole',
    	textarea : 'Textová oblast',
    	hiddenField : 'Skryté pole',
    	button : 'Tlačítko',
    	select : 'Seznam',
    	imageButton : 'Obrázkové tlačítko',
    	notSet : '<nenastaveno>',
    	id : 'Id',
    	name : 'Jméno',
    	langDir : 'Směr jazyka',
    	langDirLtr : 'Zleva doprava (LTR)',
    	langDirRtl : 'Zprava doleva (RTL)',
    	langCode : 'Kód jazyka',
    	longDescr : 'Dlouhý popis URL',
    	cssClass : 'Třída stylu',
    	advisoryTitle : 'Pomocný titulek',
    	cssStyle : 'Styl',
    	ok : 'OK',
    	cancel : 'Zrušit',
    	close : 'Zavřít',
    	preview : 'Náhled',
    	resize : 'Uchopit pro změnu velikosti',
    	generalTab : 'Obecné',
    	advancedTab : 'Rozšířené',
    	validateNumberFailed : 'Zadaná hodnota není číselná.',
    	confirmNewPage : 'Jakékoliv neuložené změny obsahu budou ztraceny. Skutečně chcete otevřít novou stránku?',
    	confirmCancel : 'Některá z nastavení byla změněna. Skutečně chcete zavřít dialogové okno?',
    	options : 'Nastavení',
    	target : 'Cíl',
    	targetNew : 'Nové okno (_blank)',
    	targetTop : 'Okno nejvyšší úrovně (_top)',
    	targetSelf : 'Stejné okno (_self)',
    	targetParent : 'Rodičovské okno (_parent)',
    	langDirLTR : 'Zleva doprava (LTR)',
    	langDirRTL : 'Zprava doleva (RTL)',
    	styles : 'Styly',
    	cssClasses : 'Třídy stylů',
    	width : 'Šířka',
    	height : 'Výška',
    	align : 'Zarovnání',
    	alignLeft : 'Vlevo',
    	alignRight : 'Vpravo',
    	alignCenter : 'Na střed',
    	alignJustify : 'Zarovnat do bloku',
    	alignTop : 'Nahoru',
    	alignMiddle : 'Na střed',
    	alignBottom : 'Dolů',
    	alignNone : 'Žádné',
    	invalidValue : 'Neplatná hodnota.',
    	invalidHeight : 'Zadaná výška musí být číslo.',
    	invalidWidth : 'Šířka musí být číslo.',
    	invalidCssLength : 'Hodnota určená pro pole "%1" musí být kladné číslo bez nebo s platnou jednotkou míry CSS (px, %, in, cm, mm, em, ex, pt, nebo pc).',
    	invalidHtmlLength : 'Hodnota určená pro pole "%1" musí být kladné číslo bez nebo s platnou jednotkou míry HTML (px nebo %).',
    	invalidInlineStyle : 'Hodnota určená pro řádkový styl se musí skládat z jedné nebo více n-tic ve formátu "název : hodnota", oddělené středníky',
    	cssLengthTooltip : 'Zadejte číslo jako hodnotu v pixelech nebo číslo s platnou jednotkou CSS (px, %, v cm, mm, em, ex, pt, nebo pc).',
    	unavailable : '%1<span class="cke_accessibility">, nedostupné</span>',
    	keyboard : 
    	{
    		'8' : 'Backspace',
    		'13' : 'Enter',
    		'16' : 'Shift',
    		'17' : 'Ctrl',
    		'18' : 'Alt',
    		'32' : 'Space',
    		'35' : 'Konec',
    		'36' : 'Domů',
    		'46' : 'Smazat',
    		'224' : 'Command'
    	},
    	keyboardShortcut : 'Keyboard shortcut'
    } }; 